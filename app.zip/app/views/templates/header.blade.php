<div class="container" style="background-color: #dd4814">
    {{ HTML::image('/assets/images/header.png', 'Cabeçalho CBR', ['class'=>'img-responsive']) }}
</div>
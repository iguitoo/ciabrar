@extends('templates.admin-master')

@section('conteudo')
<div class="col-lg-12">
   <h2 class="sub-header">Dashboard</h2>
   <div class="table-responsive">
        <table class="table table-bordered">

        </table>
   </div>
</div>
@stop